package interactions;

import org.openqa.selenium.support.ui.ExpectedConditions;
import page.ListaTarefasPage;

/**
 * Created by raphael.silva on 24/08/2017.
 */
public class ListaTarefasInteraction extends ListaTarefasPage {
    public void preencherUsuario(String usuario){
        campoUsuario.sendKeys(usuario);
    }

    public void preencherSenha(String senha){
        campoSenha.sendKeys(senha);
    }

    public void clicarEntrar(){
        btnEntrar.click();
    }

    public void clicarMinhasConsultas() {
        menuMinhasConsultas.click();
    }

    public void clicarCriarConsulta() {
        linkCriarConsultas.click();
    }

    public void chegarContexto(String usuario, String senha) throws InterruptedException {
        preencherUsuario(usuario);
        preencherSenha(senha);
        clicarEntrar();
        Thread.sleep(3000);
        clicarMinhasConsultas();
        clicarCriarConsulta();
    }
}
