package steps;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

/**
 * Created by raphael.silva on 24/08/2017.
 */
@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = "pretty",
        format={"html:target/cucumber", "json:target/cucumber.json"},
        features="src/test/java/features",
        tags = {"~@ignore"})

public class StepRunner{

}



