package steps;

import cucumber.api.PendingException;
import cucumber.api.java.pt.Dado;
import cucumber.api.java.pt.Então;
import cucumber.api.java.pt.Quando;
import interactions.ListaTarefasInteraction;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by raphael.silva on 24/08/2017.
 */
public class ListaTarefasSteps{
    public WebDriver driver = new FirefoxDriver();
    ListaTarefasInteraction listaTarefas = PageFactory.initElements(driver, ListaTarefasInteraction.class);

    @Dado("^Colaborador Sicredi da GOP visualizando a tela Criar Consulta$")
    public void colaborador_Sicredi_da_GOP_visualizando_a_tela_Criar_Consulta() throws Throwable {
        driver.get("http://wl1cred1t.tst.sicredi.net/sicredi-worklist-corporativa-web/");
        listaTarefas.chegarContexto("leonardo_pretto", "teste123");
    }

    @Quando("^preenche o campo Nome$")
    public void preenche_o_campo_Nome() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
    }

    @Quando("^aciona Salvar$")
    public void aciona_Salvar() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       // throw new PendingException();
    }

    @Então("^o sistema deve exibir a mensagem \"([^\"]*)\"$")
    public void o_sistema_deve_exibir_a_mensagem(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
    }
}
