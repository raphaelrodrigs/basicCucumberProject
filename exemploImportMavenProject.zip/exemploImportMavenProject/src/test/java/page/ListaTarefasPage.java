package page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by raphael.silva on 24/08/2017.
 */
public class ListaTarefasPage {
    @FindBy(id = "fieldUser")
    protected WebElement campoUsuario;

    @FindBy(id = "fieldPassword")
    protected WebElement campoSenha;

    @FindBy(id = "btnSubmit")
    protected WebElement btnEntrar;

    @FindBy(xpath = "//*[text() = 'Minhas Consultas']")
    protected WebElement menuMinhasConsultas;

    @FindBy(id = "listaTarefasMenu:menuCriarConsulta")
    protected WebElement linkCriarConsultas;

}
